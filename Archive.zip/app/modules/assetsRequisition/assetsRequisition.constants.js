const AssetsRequisitionFilterAbleFileds = [
  "searchTerm",
  "startDate",
  "endDate",
  "name",
];

const AssetsRequisitionSearchableFields = ["searchTerm", "name"];

module.exports = {
  AssetsRequisitionFilterAbleFileds,
  AssetsRequisitionSearchableFields,
};
