const DamageRepairFilterAbleFileds = [
  "searchTerm",
  "startDate",
  "endDate",
  "name",
];

const DamageRepairSearchableFields = ["searchTerm", "name"];

module.exports = {
  DamageRepairFilterAbleFileds,
  DamageRepairSearchableFields,
};
