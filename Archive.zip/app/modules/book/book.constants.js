
const BookFilterAbleFileds = ['searchTerm' ];
const BookSearchableFields = ['searchTerm']; // ✅ only real DB columns

module.exports = { BookFilterAbleFileds, BookSearchableFields };
