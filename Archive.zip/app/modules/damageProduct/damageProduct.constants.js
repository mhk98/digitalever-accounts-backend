const DamageProductFilterAbleFileds = [
  "searchTerm",
  "startDate",
  "endDate",
  "name",
];

const DamageProductSearchableFields = ["searchTerm", "name"];

module.exports = {
  DamageProductFilterAbleFileds,
  DamageProductSearchableFields,
};
