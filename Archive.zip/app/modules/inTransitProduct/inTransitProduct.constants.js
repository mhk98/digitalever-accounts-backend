const InTransitProductFilterAbleFileds = [
  "searchTerm",
  "startDate",
  "endDate",
  "name",
];

const InTransitProductSearchableFields = ["searchTerm", "name"];

module.exports = {
  InTransitProductFilterAbleFileds,
  InTransitProductSearchableFields,
};
