const PosReportFilterAbleFileds = [
  "searchTerm",
  "startDate",
  "endDate",
  "name",
];

const PosReportSearchableFields = ["searchTerm", "name"];

module.exports = {
  PosReportFilterAbleFileds,
  PosReportSearchableFields,
};
