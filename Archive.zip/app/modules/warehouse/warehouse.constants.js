const WarehouseFilterAbleFileds = ["searchTerm"];
const WarehouseSearchableFields = ["searchTerm"]; // ✅ only real DB columns

module.exports = { WarehouseFilterAbleFileds, WarehouseSearchableFields };
