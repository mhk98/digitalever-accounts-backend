const PayableFilterAbleFields = ["searchTerm", "name", "startDate", "endDate"];

// ✅ শুধু text field searchable হবে
const PayableSearchableFields = ["name"];

module.exports = {
  PayableFilterAbleFields,
  PayableSearchableFields,
};
