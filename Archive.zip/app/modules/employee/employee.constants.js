const EmployeeFilterAbleFileds = ["searchTerm", "startDate", "endDate", "name"];

const EmployeeSearchableFields = ["searchTerm"];

module.exports = {
  EmployeeFilterAbleFileds,
  EmployeeSearchableFields,
};
