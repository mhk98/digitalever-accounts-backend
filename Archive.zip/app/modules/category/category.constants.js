const CategoryFilterAbleFileds = ["searchTerm"];
const CategorySearchableFields = ["searchTerm"]; // ✅ only real DB columns

module.exports = { CategoryFilterAbleFileds, CategorySearchableFields };
