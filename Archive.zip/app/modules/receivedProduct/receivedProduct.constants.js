const ReceivedProductFilterAbleFileds = [
  "searchTerm",
  "startDate",
  "endDate",
  "name",
];

const ReceivedProductSearchableFields = ["searchTerm"];

module.exports = {
  ReceivedProductFilterAbleFileds,
  ReceivedProductSearchableFields,
};
