const ReceivedProductFilterAbleFileds = [
  "searchTerm",
  "startDate",
  "endDate",
  "name",
];

const ReceivedProductSearchableFields = ["searchTerm", "name"];

module.exports = {
  ReceivedProductFilterAbleFileds,
  ReceivedProductSearchableFields,
};
