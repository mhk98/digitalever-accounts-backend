const SupplierFilterAbleFileds = ["searchTerm"];
const SupplierSearchableFields = ["searchTerm"]; // ✅ only real DB columns

module.exports = { SupplierFilterAbleFileds, SupplierSearchableFields };
