 const AssetsPurchaseFilterAbleFileds = ['searchTerm', 'startDate', 'endDate', 'name'];

 const AssetsPurchaseSearchableFields = ['searchTerm', 'name'];


module.exports = {

    AssetsPurchaseFilterAbleFileds,
    AssetsPurchaseSearchableFields

}