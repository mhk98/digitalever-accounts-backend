const WarrantyProductFilterAbleFileds = [
  "searchTerm",
  "startDate",
  "endDate",
  "name",
];

const WarrantyProductSearchableFields = ["name"];

module.exports = {
  WarrantyProductFilterAbleFileds,
  WarrantyProductSearchableFields,
};
