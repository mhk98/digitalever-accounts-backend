const AssetsDamageFilterAbleFileds = [
  "searchTerm",
  "startDate",
  "endDate",
  "name",
];

const AssetsDamageSearchableFields = ["searchTerm", "name"];

module.exports = {
  AssetsDamageFilterAbleFileds,
  AssetsDamageSearchableFields,
};
