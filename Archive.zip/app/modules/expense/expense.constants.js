 const ExpenseFilterAbleFileds = ['searchTerm', 'startDate', 'endDate', 'name'];

 const ExpenseSearchableFields = ['searchTerm', 'name'];


module.exports = {

    ExpenseFilterAbleFileds,
    ExpenseSearchableFields

}