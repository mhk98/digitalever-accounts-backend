 const CashInFilterAbleFileds = ['searchTerm', 'startDate', 'endDate'];

 const CashInSearchableFields = ['searchTerm',];


module.exports = {

    CashInFilterAbleFileds,
    CashInSearchableFields

}