const ReturnProductFilterAbleFileds = [
  "searchTerm",
  "startDate",
  "endDate",
  "name",
];

const ReturnProductSearchableFields = ["searchTerm", "name"];

module.exports = {
  ReturnProductFilterAbleFileds,
  ReturnProductSearchableFields,
};
