// app/modules/overview/overview.constants.js

const OverviewFilterAbleFileds = ["from", "to"];

module.exports = { OverviewFilterAbleFileds };
