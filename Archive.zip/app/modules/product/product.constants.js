 const ProductFilterAbleFileds = ['searchTerm', 'startDate', 'endDate', 'name'];

 const ProductSearchableFields = ['searchTerm', ];


module.exports = {

    ProductFilterAbleFileds,
    ProductSearchableFields

}