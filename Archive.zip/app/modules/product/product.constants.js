const ProductFilterAbleFileds = [
  "searchTerm",
  "startDate",
  "endDate",
  "name",
  "warehouseId",
];

const ProductSearchableFields = ["searchTerm"];

module.exports = {
  ProductFilterAbleFileds,
  ProductSearchableFields,
};
