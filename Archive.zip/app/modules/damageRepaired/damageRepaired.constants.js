const DamageRepairedFilterAbleFileds = [
  "searchTerm",
  "startDate",
  "endDate",
  "name",
];

const DamageRepairedSearchableFields = ["searchTerm", "name"];

module.exports = {
  DamageRepairedFilterAbleFileds,
  DamageRepairedSearchableFields,
};
