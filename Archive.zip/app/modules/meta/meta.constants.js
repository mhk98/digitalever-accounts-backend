const MetaFilterAbleFileds = ["searchTerm", "startDate", "endDate", "platform"];

const MetaSearchableFields = ["searchTerm"];

module.exports = {
  MetaFilterAbleFileds,
  MetaSearchableFields,
};
