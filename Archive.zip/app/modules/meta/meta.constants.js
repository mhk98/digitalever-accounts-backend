 const MetaFilterAbleFileds = ['searchTerm', 'startDate', 'endDate'];

 const MetaSearchableFields = ['searchTerm',];


module.exports = {

    MetaFilterAbleFileds,
    MetaSearchableFields

}