const PurchaseReturnProductFilterAbleFileds = [
  "searchTerm",
  "startDate",
  "endDate",
  "name",
];

const PurchaseReturnProductSearchableFields = ["searchTerm", "name"];

module.exports = {
  PurchaseReturnProductFilterAbleFileds,
  PurchaseReturnProductSearchableFields,
};
