const PurchaseRequisitionFilterAbleFileds = [
  "searchTerm",
  "startDate",
  "endDate",
  "name",
];

const PurchaseRequisitionSearchableFields = ["searchTerm"];

module.exports = {
  PurchaseRequisitionFilterAbleFileds,
  PurchaseRequisitionSearchableFields,
};
