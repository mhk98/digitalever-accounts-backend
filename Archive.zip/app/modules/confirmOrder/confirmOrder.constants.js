const ConfirmOrderFilterAbleFileds = [
  "searchTerm",
  "startDate",
  "endDate",
  "name",
];

const ConfirmOrderSearchableFields = ["name"];

module.exports = {
  ConfirmOrderFilterAbleFileds,
  ConfirmOrderSearchableFields,
};
