const ConfirmOrderFilterAbleFileds = [
  "searchTerm",
  "startDate",
  "endDate",
  "name",
];

const ConfirmOrderSearchableFields = ["searchTerm", "name"];

module.exports = {
  ConfirmOrderFilterAbleFileds,
  ConfirmOrderSearchableFields,
};
