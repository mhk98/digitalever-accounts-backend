const AssetsSaleFilterAbleFileds = [
  "searchTerm",
  "startDate",
  "endDate",
  "name",
];

const AssetsSaleSearchableFields = ["searchTerm", "name"];

module.exports = {
  AssetsSaleFilterAbleFileds,
  AssetsSaleSearchableFields,
};
