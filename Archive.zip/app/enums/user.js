// Correct way to define an enum-like object in JavaScript
exports.ENUM_USER_ROLE = {
    SUPER_ADMIN: 'superAdmin',
    MARKETER: 'marketer',
    LEADER: 'leader',
    INVENTOR: 'inventor',
    ACCOUNTANT: 'accountant',
    STAFF: 'staff',
   
  };
  